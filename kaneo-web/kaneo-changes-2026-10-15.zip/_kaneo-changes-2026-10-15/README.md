# kaneo 变更包：2026-10-15 全量

- 来源工作区：`kaneo/`（分支 `main` @ `4c89504d`，版本 `2.46.2`）
- 导出时间：2026-10-15
- 范围：工作区全部 text 改动（7 个修改 + 3 个新增）

## 包含的文件（10 个 text + 1 个 patch + 本 README）

### 修改的跟踪文件（7）

| 路径 | 增量 | 说明 |
| --- | --- | --- |
| `.env.sample` | +5 行 | API Key 登录开关（`API_KEY_SIGN_IN` / `API_KEY_SIGN_IN_ADMIN_ONLY`）+ B 方案的 `KANEO_COOKIE_SAMESITE` |
| `apps/api/src/auth.ts` | +2 行 | 注册 `apiKeySignIn()` 插件端点（API Key 登录） |
| `apps/api/src/utils/get-default-cookie-attributes.ts` | +20 / -6 | B 方案：`KANEO_COOKIE_SAMESITE=none` 开启时强制 `None+Secure+Partitioned` + 启动 warn |
| `apps/docs/api-reference/authentication.mdx` | +13 行 | 新增 "Sign in from a link" 小节 |
| `apps/docs/core/installation/environment-variables.mdx` | +2 行 | Authentication 表新增 2 行 |
| `apps/web/nginx.conf` | +5 / -1 | `X-Frame-Options: SAMEORIGIN` → `Content-Security-Policy: "frame-ancestors 'self'"` |
| `apps/web/nginx.kaneo.conf` | +5 / -1 | 同上 |

### 新增的未跟踪文件（3）

| 路径 | 说明 |
| --- | --- |
| `apps/api/src/api-key-sign-in/index.ts` | API Key 登录的 better-auth 插件端点 |
| `tests/api-integration/api-key-sign-in.test.ts` | 集成测试（8 个用例） |
| `Kaneo-API-Key.md` | API Key 登录特性 + B 方案的方案说明书（两份内容合并在仓库根） |

### 配套

| 路径 | 说明 |
| --- | --- |
| `_kaneo-changes-2026-10-15/CHANGES.patch` | 上述 7 个修改文件的 `git diff`，可用 `git apply` 复核或应用 |
| `_kaneo-changes-2026-10-15/README.md` | 本文档 |

## 未包含的 2 个仓库内符号链接

`git status` 列出的下面两条是仓库内的符号链接（mode 120000），不是内容改动：

| 路径 | 指向 |
| --- | --- |
| `.claude/skills` | `../.agents/skills` |
| `packages/email/src/templates/static` | `../../../../apps/web/public/email` |

- 在当前工作区对它们 `git diff` 为空（指向未变）。
- 在 Windows checkout 下常被 git 报成 "modified"，属于显示层差异。
- 把它们打进 zip 没有意义（要么复制 symlink 自身、要么复制 target 路径字符串），故排除。

## 应用方式

方式一：直接覆盖（推荐）
```bash
unzip kaneo-changes-2026-10-15.zip -d /tmp/kc
cp -r /tmp/kc/. /path/to/kaneo/    # _kaneo-changes-2026-10-15/ 目录可忽略
```

方式二：只应用补丁（新增文件需另行复制）
```bash
git -C /path/to/kaneo apply /tmp/kc/_kaneo-changes-2026-10-15/CHANGES.patch
```

## 部署启用（不在本包里，文档级提示）

1. **API Key 登录**：
   - `.env` 加上 `API_KEY_SIGN_IN=true`（按需 `API_KEY_SIGN_IN_ADMIN_ONLY=true`）。
   - 确认 `KANEO_CLIENT_URL` 与浏览器访问地址一致。

2. **B 方案（跨站 iframe cookie）**：
   - `.env` 加上 `KANEO_COOKIE_SAMESITE=none`。
   - 外层 nginx（前置反代）：
     ```nginx
     proxy_hide_header Content-Security-Policy;
     add_header Content-Security-Policy "frame-ancestors 'self' http://127.0.0.1:3080" always;
     proxy_hide_header X-Frame-Options;   # no-op（B 后容器已不发），保留无害
     ```
   - 详见 [Kaneo-iframe-选型-B方案详解.md](../Kaneo-iframe-选型-B方案详解.md) 与 [nginx-outer-frame-ancestors.conf](../nginx-outer-frame-ancestors.conf)。

## 验证

```bash
# ① API Key 端点已部署并启用
curl -sS -o /dev/null -w '%{http_code}\n' \
  "https://pl.feg.cn/api/auth/api-key/sign-in?key=invalid"
# 期望 401（端点存在 + API_KEY_SIGN_IN=true）

# ② B 方案的 cookie 属性
curl -sS -D - -o /dev/null -X POST https://pl.feg.cn/api/auth/sign-out \
  -H "content-type: application/json" -d '{}' | grep -i set-cookie
# 期望看到 SameSite=None; Partitioned

# ③ 外层 CSP
curl -sSI https://pl.feg.cn/ | grep -i 'content-security'
# 期望恰好一条 CSP，含 'self' 与 'http://127.0.0.1:3080'
```

## 边界与回滚

- **API Key 登录**：关闭 `API_KEY_SIGN_IN` 立即失效（端点 404）；删除对应 Key 立即无效。
- **B 方案**：把 `KANEO_COOKIE_SAMESITE` 留空或改 `lax`，重 API → 立刻回到 `Lax` 行为。Safari/Firefox 在 B 下仍不工作（CHIPS 限制），要全浏览器需后续上 C 方案。