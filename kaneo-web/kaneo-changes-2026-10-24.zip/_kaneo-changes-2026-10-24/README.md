# kaneo 变更包：Run-As（以任意账号操作）

- 来源工作区：`kaneo/`（分支 `main`，基线 commit `daf1a9d2 "api-key and mcp"`）
- 导出时间：2026-10-24
- 范围：本次 run-as 特性（8 个修改 + 2 个新增）
- **无 schema 变更、无迁移、无前端改动**

---

## 1. 特性

API Key 认证的请求可以带 `x-run-as` 头（值为 user id 或 email），**以该用户身份**执行。

```bash
curl -X GET https://pl.feg.cn/api/user/me \
  -H "Authorization: Bearer $KEY" \
  -H "x-run-as: teammate@example.com"
```

| 规则 | 说明 |
| --- | --- |
| 仅 API Key 认证 | session / cookie 请求**忽略**该 header |
| 仅 instance admin | key owner 每次请求现读 DB 的 `role` |
| 精确扮演 | 权限 **完全等于**目标用户，不叠加执行者的 admin 权力 |
| scope 仍是天花板 | key 的 `permissions` scope 照常生效（只读 key → 只读） |
| 目标须存在且未被 ban | 否则 404 / 403 |
| 响应回显 | `x-kaneo-run-as: <effective user id>` |
| 留痕 | `[run-as] actor=… target=… method=… path=…` 进 API 日志 + `run_as.used` 事件 |
| 开关 | `RUN_AS_ENABLED`（默认开启，设 `false` 全站关闭） |

MCP 同样支持：`POST /api/mcp` 带 `x-run-as` → 工具调用向下游 REST 转发同一个 `x-run-as`，因此工具是以目标身份执行的。

---

## 2. 内容

| 路径 | 状态 | 说明 |
| --- | --- | --- |
| `apps/api/src/utils/run-as.ts` | **新增** | 核心模块：解析目标、校验执行者是 admin、交换有效身份、留痕。同请求内幂等 |
| `apps/api/src/utils/authenticate-api-request.ts` | 修改 | `setApiKeyContext` 改 async 并调用 `applyRunAs`；`resolveAssetBearerOrCookie` 的 key 分支同样应用（asset 路由会重新解析身份） |
| `apps/api/src/utils/validate-workspace-access.ts` | 修改 | 去掉 key 归属比较（原为恒真），run-as 下 effective user 是目标、key 属于执行者，**3 个调用点无需改动** |
| `apps/api/src/mcp/index.ts` | 修改 | `validateBearerToken` 改用 Context 并应用 run-as；把目标 id 传给下游 |
| `apps/api/src/mcp/modern.ts` | 修改 | 透传 `runAsTargetId` |
| `apps/api/src/mcp/tools.ts` | 修改 | 下游 REST 请求带上 `x-run-as` |
| `.env.sample` | 修改 | 新增 `RUN_AS_ENABLED` |
| `apps/docs/core/installation/environment-variables.mdx` | 修改 | Authentication 表加一行 |
| `apps/docs/api-reference/authentication.mdx` | 修改 | 新增 "Run as another user" 小节 |
| `tests/api-integration/run-as.test.ts` | **新增** | 8 个用例 |
| `_kaneo-changes-2026-10-24/CHANGES.patch` | 参考 | 8 个修改文件的 `git diff` |

---

## 3. 应用

```bash
unzip kaneo-changes-2026-10-24.zip -d /tmp/kc
cp -r /tmp/kc/. /path/to/kaneo/        # _kaneo-changes-2026-10-24/ 可忽略
```

或只打补丁（新增文件需另行复制）：
```bash
git -C /path/to/kaneo apply /tmp/kc/_kaneo-changes-2026-10-24/CHANGES.patch
```

**不需要数据库迁移。** 部署后重启 API 即可。

---

## 4. 验证

```bash
# ① 目标身份生效
curl -s https://pl.feg.cn/api/user/me -H "Authorization: Bearer $KEY" -H "x-run-as: <目标email>"
# 期望: 返回目标用户；响应头 x-kaneo-run-as: <目标id>

# ② 非 admin 被拒 → 403

# ③ RUN_AS_ENABLED=false 重启后 → 403

# ④ MCP
curl -X POST https://pl.feg.cn/api/mcp \
  -H "Authorization: Bearer $KEY" -H "x-run-as: <目标id>" \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"probe","version":"0"}}}'
# 期望 200
```

集成测试（需 PostgreSQL）：
```bash
pnpm --filter @kaneo/api test:integration -- run-as
```

---

## 5. 边界与风险

| 项 | 说明 |
| --- | --- |
| key 泄露的爆炸半径变大 | 持有 admin key 的人能读任意用户的私有内容。建议用**专用 key** + 只读 scope + 定期轮换 |
| 留痕不是审计表 | 只有 API 日志 + 内存事件总线；留存期取决于你的日志系统 |
| 业务活动记成目标用户 | 任务评论/通知的 `createdBy` 是目标，不是执行者 |
| 账户级路由仍不可达 | `/api/admin/*`、`/api/billing/*` 对 API key 请求一律 403 `SESSION_REQUIRED` |
| 回滚 | `RUN_AS_ENABLED=false` 立即全站失效（读 env，不需重启） |