#!/usr/bin/env node
/**
 * minio.mjs — 零依賴的 MinIO / S3 檔案操作（給 `minio-file` skill 用）
 *
 * 它自己實作 AWS SigV4（約 120 行 HMAC 鏈），所以不需要 `@aws-sdk/client-s3`、
 * 不需要 `mc`，只要有 Node 18+。連線設定直接吃 dsh-minio-s3 面板
 * 「❗️ 複製設定」匯出的 JSON。
 *
 *   node minio.mjs ls --config minio.json
 *   node minio.mjs put --config minio.json --key docs/a.md --from a.md
 *   node minio.mjs get --config minio.json --key docs/a.md --out a.md
 *
 * 設定解析順序：--config <file> → $MINIO_CONFIG → ./minio.json → 環境變數
 * （MINIO_ENDPOINT / MINIO_ACCESS_KEY / MINIO_SECRET_KEY / MINIO_REGION / MINIO_BUCKET）。
 * 欄位名同時接受匯出格式（endpoint/accessKey/secretKey/region/bucket）與
 * BDD storage 記錄的原始格式（S3_URL/S3_UID/S3_PWD/S3_BUCK、UID/PWD/BUCKET）。
 *
 * 結束碼：0 成功；1 失敗（stderr 一行 `error: <Code> <Message>`）。
 */

import { createHash, createHmac } from 'node:crypto'
import { readFileSync, writeFileSync } from 'node:fs'
import { basename } from 'node:path'

const EMPTY_SHA256 = 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
const UNSIGNED_PAYLOAD = 'UNSIGNED-PAYLOAD'
const DEFAULT_REGION = 'us-east-1'

// ---------------------------------------------------------------------------
// 參數
// ---------------------------------------------------------------------------

function parseArgv(argv) {
  const out = { _: [], key: [], flags: {} }
  for (let i = 0; i < argv.length; i += 1) {
    const token = argv[i]
    if (token === '--json' || token === '--recursive' || token === '--help' || token === '-h') {
      out.flags[token.replace(/^--?/, '')] = true
      continue
    }
    if (token.startsWith('--')) {
      const name = token.slice(2)
      const value = argv[i + 1]
      if (value === undefined || value.startsWith('--')) {
        out.flags[name] = true
        continue
      }
      i += 1
      if (name === 'key') out.key.push(value)
      else out.flags[name] = value
      continue
    }
    out._.push(token)
  }
  return out
}

// ---------------------------------------------------------------------------
// 設定
// ---------------------------------------------------------------------------

function pick(object, names) {
  const lowered = new Map(Object.entries(object || {}).map(([k, v]) => [k.toLowerCase(), v]))
  for (const name of names) {
    const value = lowered.get(name.toLowerCase())
    if (typeof value === 'string' && value.trim() !== '') return value.trim()
    if (typeof value === 'number') return String(value)
  }
  return ''
}

function loadConfig(args) {
  const candidates = []
  if (typeof args.flags.config === 'string') candidates.push(args.flags.config)
  if (process.env.MINIO_CONFIG) candidates.push(process.env.MINIO_CONFIG)
  candidates.push('minio.json', '.dsh/minio.json')

  let raw = {}
  let source = 'environment'
  for (const candidate of candidates) {
    try {
      raw = JSON.parse(readFileSync(candidate, 'utf8'))
      source = candidate
      break
    } catch (error) {
      if (typeof args.flags.config === 'string' && candidate === args.flags.config) {
        fail('ConfigUnreadable', `讀不到設定檔 ${candidate}：${error.message}`)
      }
    }
  }

  const endpointRaw = pick(raw, ['endpoint', 'S3_URL', 'url', 'host']) || process.env.MINIO_ENDPOINT || ''
  const accessKey = pick(raw, ['accessKey', 'accessKeyId', 'S3_UID', 'UID']) || process.env.MINIO_ACCESS_KEY || ''
  const secretKey = pick(raw, ['secretKey', 'secretAccessKey', 'S3_PWD', 'PWD']) || process.env.MINIO_SECRET_KEY || ''
  const region = pick(raw, ['region', 'S3_REGION']) || process.env.MINIO_REGION || ''
  const bucket = typeof args.flags.bucket === 'string'
    ? args.flags.bucket
    : (pick(raw, ['bucket', 'S3_BUCK', 'BUCKET']) || process.env.MINIO_BUCKET || '')

  if (endpointRaw === '' || accessKey === '' || secretKey === '') {
    fail('ConfigMissing', `設定缺少 endpoint/accessKey/secretKey（試過：${candidates.join('、')}）。`
      + '第一次使用請把 dsh-minio-s3 面板「❗️ 複製設定」匯出的 JSON 交給 `minio.mjs init`（或用 --config 指定檔案），'
      + '也可以用 MINIO_ENDPOINT/MINIO_ACCESS_KEY/MINIO_SECRET_KEY 環境變數。')
  }
  const endpoint = (/^https?:\/\//i.test(endpointRaw) ? endpointRaw : `http://${endpointRaw}`).replace(/\/+$/, '')
  return { endpoint, accessKey, secretKey, region, bucket, source }
}

// ---------------------------------------------------------------------------
// SigV4
// ---------------------------------------------------------------------------

const sha256Hex = (data) => createHash('sha256').update(data).digest('hex')
const hmac = (key, data) => createHmac('sha256', key).update(data).digest()

function amzStamp(now = new Date()) {
  const iso = now.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, '')
  return { stamp: iso, date: iso.slice(0, 8) }
}

const uriEncode = (value) => encodeURIComponent(String(value))
  .replace(/[!'()*]/g, (ch) => '%' + ch.charCodeAt(0).toString(16).toUpperCase())
const uriEncodePath = (value) => uriEncode(value).replace(/%2F/gi, '/')

function canonicalQuery(pairs) {
  const encoded = (pairs || [])
    .filter((pair) => pair && pair[0])
    .map(([k, v]) => [uriEncode(k), v === undefined || v === null ? '' : uriEncode(v)])
  encoded.sort((a, b) => (a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : a[1] < b[1] ? -1 : a[1] > b[1] ? 1 : 0))
  return encoded.map(([k, v]) => `${k}=${v}`).join('&')
}

function payloadHashOf(body) {
  if (body === undefined || body === null) return EMPTY_SHA256
  if (typeof body === 'string') return body === '' ? EMPTY_SHA256 : sha256Hex(body)
  if (body.length === 0) return EMPTY_SHA256
  return sha256Hex(body)
}

function signingKey(secretKey, date, region, service = 's3') {
  return hmac(hmac(hmac(hmac(`AWS4${secretKey}`, date), region), service), 'aws4_request')
}

function sign({ method, url, headers = {}, body, accessKey, secretKey, region, now }) {
  const parsed = url instanceof URL ? url : new URL(url)
  const { stamp, date } = amzStamp(now)
  const payloadHash = payloadHashOf(body)

  const all = {}
  for (const [name, value] of Object.entries(headers)) {
    if (value === undefined || value === null) continue
    all[name.toLowerCase()] = String(value).trim().replace(/\s+/g, ' ')
  }
  all.host = parsed.host
  all['x-amz-date'] = stamp
  all['x-amz-content-sha256'] = payloadHash

  const signedHeaders = Object.keys(all).sort()
  const query = canonicalQuery([...parsed.searchParams.entries()])
  // canonical headers 每一行（含最後一行）都以 \n 結尾 —— 少了那個空行，
  // 本地看起來一切正常，伺服器卻永遠回 SignatureDoesNotMatch。
  const canonicalHeaders = signedHeaders.map((name) => `${name}:${all[name]}`).join('\n') + '\n'
  const canonicalRequest = [
    method.toUpperCase(),
    parsed.pathname === '' ? '/' : parsed.pathname,
    query,
    canonicalHeaders,
    signedHeaders.join(';'),
    payloadHash,
  ].join('\n')

  const scope = `${date}/${region}/s3/aws4_request`
  const stringToSign = ['AWS4-HMAC-SHA256', stamp, scope, sha256Hex(canonicalRequest)].join('\n')
  const signature = hmac(signingKey(secretKey, date, region), stringToSign).toString('hex')

  const out = {}
  for (const [name, value] of Object.entries(headers)) {
    if (value === undefined || value === null) continue
    out[name] = value
  }
  out['x-amz-date'] = stamp
  out['x-amz-content-sha256'] = payloadHash
  out.Authorization = `AWS4-HMAC-SHA256 Credential=${accessKey}/${scope}`
    + `, SignedHeaders=${signedHeaders.join(';')}, Signature=${signature}`
  return out
}

function presign({ url, method = 'GET', accessKey, secretKey, region, expires = 3600, now }) {
  const parsed = url instanceof URL ? url : new URL(url)
  const { stamp, date } = amzStamp(now)
  const scope = `${date}/${region}/s3/aws4_request`
  const pairs = [...parsed.searchParams.entries()].concat([
    ['X-Amz-Algorithm', 'AWS4-HMAC-SHA256'],
    ['X-Amz-Credential', `${accessKey}/${scope}`],
    ['X-Amz-Date', stamp],
    ['X-Amz-Expires', String(Math.max(1, Math.min(604800, Math.floor(expires))))],
    ['X-Amz-SignedHeaders', 'host'],
  ])
  const query = canonicalQuery(pairs)
  const canonicalRequest = [
    method.toUpperCase(),
    parsed.pathname === '' ? '/' : parsed.pathname,
    query,
    `host:${parsed.host}\n`,
    'host',
    UNSIGNED_PAYLOAD,
  ].join('\n')
  const signature = hmac(
    signingKey(secretKey, date, region),
    ['AWS4-HMAC-SHA256', stamp, scope, sha256Hex(canonicalRequest)].join('\n'),
  ).toString('hex')
  return `${parsed.origin}${parsed.pathname}?${query}&X-Amz-Signature=${signature}`
}

// ---------------------------------------------------------------------------
// XML（只解我們要的欄位）
// ---------------------------------------------------------------------------

const decodeEntities = (text) => String(text).replace(/&(#x?[0-9a-fA-F]+|amp|lt|gt|quot|apos);/g, (match, entity) => {
  if (entity === 'amp') return '&'
  if (entity === 'lt') return '<'
  if (entity === 'gt') return '>'
  if (entity === 'quot') return '"'
  if (entity === 'apos') return "'"
  if (entity[0] === '#') {
    const code = entity[1] === 'x' || entity[1] === 'X' ? parseInt(entity.slice(2), 16) : parseInt(entity.slice(1), 10)
    if (Number.isFinite(code)) { try { return String.fromCodePoint(code) } catch { return match } }
  }
  return match
})

function xmlText(xml, tag) {
  const match = new RegExp(`<${tag}(?:\\s[^>]*)?>([\\s\\S]*?)</${tag}>`).exec(String(xml || ''))
  return match ? decodeEntities(match[1]).trim() : null
}

function xmlBlocks(xml, tag) {
  const out = []
  const pattern = new RegExp(`<${tag}(?:\\s[^>]*)?>([\\s\\S]*?)</${tag}>`, 'g')
  let match
  while ((match = pattern.exec(String(xml || ''))) !== null) out.push(match[1])
  return out
}

// MinIO 的 ListObjectsV2 用 url.QueryEscape（空間 → +、+ → %2B）；
// decodeURIComponent 不認 +，少了這一步 key 會對不上。
const decodeKey = (value) => {
  if (!value) return ''
  try { return decodeURIComponent(String(value).replace(/\+/g, ' ')) } catch { return String(value) }
}

function parseError(text, status) {
  return {
    code: xmlText(text, 'Code') || `HTTP${status}`,
    message: xmlText(text, 'Message') || String(text || '').slice(0, 300),
    region: xmlText(text, 'Region') || '',
    status,
  }
}

/**
 * 失敗：拋出帶訊息的 CLI 錯誤，由最外層統一印出並設 exit code。
 *
 * 刻意**不用 `process.exit()`**：Node 24 on Windows 在 fetch 的 socket 正在收尾時
 * 呼叫 process.exit() 會踩到 libuv 的 `UV_HANDLE_CLOSING` 斷言，行程以
 * 0xC0000409 結束（不是 1），呼叫端看到的是「crash」而不是可讀的錯誤。
 */
class CliError extends Error {}

function fail(code, message, status = 0) {
  throw new CliError(`${code}${message ? ' ' + message : ''}${status ? ` (HTTP ${status})` : ''}`)
}

// ---------------------------------------------------------------------------
// HTTP
// ---------------------------------------------------------------------------

function makeClient(config) {
  const state = { region: config.region || DEFAULT_REGION }

  async function probeRegion() {
    if (config.region) return
    try {
      const response = await fetch(`${config.endpoint}/`)
      if (response.ok) return
      const region = parseError(await response.text(), response.status).region
      if (region) state.region = region
    } catch { /* 探測失敗就用預設 */ }
  }

  function objectUrl(bucket, key) {
    let path = ''
    if (bucket) path += `/${uriEncode(bucket)}`
    if (key) path += `/${uriEncodePath(key)}`
    return config.endpoint + (path === '' ? '/' : path)
  }

  function withQuery(url, pairs) {
    const parsed = new URL(url)
    for (const [k, v] of pairs || []) {
      if (v === undefined || v === null) continue
      parsed.searchParams.set(k, String(v))
    }
    return parsed.toString()
  }

  async function send({ method = 'GET', url, headers = {}, body }) {
    const requestHeaders = sign({
      method,
      url,
      headers,
      body,
      accessKey: config.accessKey,
      secretKey: config.secretKey,
      region: state.region,
    })
    const init = { method, headers: requestHeaders }
    if (body !== undefined && body !== null) init.body = body
    let response
    try {
      response = await fetch(url, init)
    } catch (error) {
      fail('NetworkError', `${method} ${config.endpoint} 失敗：${error.message}`)
    }
    if (!response.ok) {
      const text = await response.text()
      const info = parseError(text, response.status)
      // region 猜錯時有機會自動修正一次（伺服器會回它期待的 region）
      if (info.region && info.region !== state.region && method !== 'POST') {
        state.region = info.region
        return send({ method, url, headers, body })
      }
      fail(info.code, info.message, info.status)
    }
    return response
  }

  async function text(options) {
    return (await send(options)).text()
  }

  return { state, probeRegion, objectUrl, withQuery, send, text }
}

// ---------------------------------------------------------------------------
// 操作
// ---------------------------------------------------------------------------

async function listBuckets(client) {
  const xml = await client.text({ url: client.objectUrl('', '') })
  return xmlBlocks(xml, 'Bucket').map((block) => ({
    name: xmlText(block, 'Name') || '',
    createdAt: xmlText(block, 'CreationDate') || '',
  }))
}

async function listObjects(client, bucket, prefix, recursive, max) {
  const xml = await client.text({
    url: client.withQuery(client.objectUrl(bucket, ''), [
      ['list-type', '2'],
      ['prefix', prefix || ''],
      ['delimiter', recursive ? '' : '/'],
      ['max-keys', String(Math.max(1, Math.min(1000, max)))],
      ['encoding-type', 'url'],
    ]),
  })
  return {
    folders: xmlBlocks(xml, 'CommonPrefixes').map((block) => decodeKey(xmlText(block, 'Prefix') || '')),
    objects: xmlBlocks(xml, 'Contents').map((block) => ({
      key: decodeKey(xmlText(block, 'Key') || ''),
      size: Number(xmlText(block, 'Size') || 0),
      lastModified: xmlText(block, 'LastModified') || '',
      etag: (xmlText(block, 'ETag') || '').replace(/^"|"$/g, ''),
    })),
    truncated: (xmlText(xml, 'IsTruncated') || '').toLowerCase() === 'true',
    nextToken: decodeKey(xmlText(xml, 'NextContinuationToken') || ''),
  }
}

async function getObject(client, bucket, key, out) {
  const response = await client.send({ url: client.objectUrl(bucket, key) })
  const buffer = Buffer.from(await response.arrayBuffer())
  if (out) writeFileSync(out, buffer)
  return { bytes: buffer.length, contentType: response.headers.get('content-type') || '', body: buffer }
}

async function putObject(client, bucket, key, body, contentType) {
  const headers = {}
  if (contentType) headers['Content-Type'] = contentType
  const response = await client.send({ method: 'PUT', url: client.objectUrl(bucket, key), headers, body })
  return { key, bytes: Buffer.byteLength(body), etag: (response.headers.get('etag') || '').replace(/^"|"$/g, '') }
}

async function deleteObjects(client, bucket, keys) {
  if (keys.length > 1000) fail('TooManyKeys', `一次最多 1000 個 key（收到 ${keys.length}）`)
  const body = Buffer.from('<?xml version="1.0" encoding="UTF-8"?><Delete><Quiet>false</Quiet>'
    + keys.map((key) => `<Object><Key>${String(key)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&apos;')}</Key></Object>`).join('')
    + '</Delete>')
  const xml = await client.text({
    method: 'POST',
    url: client.withQuery(client.objectUrl(bucket, ''), [['delete', '']]),
    headers: {
      'Content-Type': 'application/xml',
      // MinIO 對 POST ?delete 要求 Content-MD5（少了它回 Missing required header）
      'Content-MD5': createHash('md5').update(body).digest('base64'),
    },
    body,
  })
  const errors = xmlBlocks(xml, 'Error').map((block) => ({
    key: xmlText(block, 'Key') || '',
    code: xmlText(block, 'Code') || '',
    message: xmlText(block, 'Message') || '',
  }))
  const deleted = xmlBlocks(xml, 'Deleted').map((block) => xmlText(block, 'Key') || '')
  // 逐 key 失敗（尤其是 region 錯誤）時退回單物件刪除：POST ?delete 的驗簽比
  // DELETE /object 嚴，只走批次會得到「HTTP 200 但什麼都沒刪」的假成功。
  const retried = []
  for (const entry of errors) {
    if (!entry.key) continue
    try {
      await client.send({ method: 'DELETE', url: client.objectUrl(bucket, entry.key) })
      deleted.push(entry.key)
      retried.push(entry.key)
    } catch { /* 保留在 errors 裡 */ }
  }
  return { deleted, errors: errors.filter((entry) => !retried.includes(entry.key)), retried }
}

async function copyObject(client, bucket, fromKey, toKey) {
  await client.send({
    method: 'PUT',
    url: client.objectUrl(bucket, toKey),
    // x-amz-copy-source 必須以 / 開頭，且 key 依 URL 規則編碼
    headers: { 'x-amz-copy-source': `/${uriEncode(bucket)}/${uriEncodePath(fromKey)}` },
  })
  return { fromKey, toKey }
}

// ---------------------------------------------------------------------------
// CLI
// ---------------------------------------------------------------------------

const USAGE = `minio.mjs — MinIO/S3 檔案操作（零依賴，自行實作 SigV4）

用法：node minio.mjs <命令> [選項]

  buckets                                    列出所有桶
  ls [prefix]                                列一層（--bucket <桶>）
     --recursive                             列出前綴下所有物件
     --max <n>                               最多幾筆（預設 200）
  head --key <key>                           物件的存在、大小、型別（HEAD）
  get --key <key> [--out <path>]             下載（--out 省略時寫到 stdout 的原始位元組）
  cat --key <key>                            以 UTF-8 讀出物件內容
  put --key <key> (--from <path>|--content <text>) [--contentType <mime>]
  rm --key <key> [--key <key> ...]            刪除（逐 key 失敗會自動逐一重試）
  mv --key <來源> --to <目標>                 複製 + 刪除原檔（S3 沒有 rename）
  mkdir --key <prefix/>                      建立資料夾標記
  mb --bucket <桶> / rb --bucket <桶>         建立 / 刪除桶（僅空桶）
  presign --key <key> [--expires 3600]        產生簽章連結

設定（第一次使用、以及之後要改的時候）：
  init [--from <file>|--content <json>] [--out <file>]
                                              把匯出的設定寫成設定檔（預設 ./minio.json）
                                              沒給 --from/--content 就從 stdin 讀
                                              （PowerShell 直接傳 --content 會被引號規則吃掉，
                                                請用 --from 或把 JSON 用管線進 stdin）
  config                                      顯示目前用的是哪一份設定（金鑰遮蔽）

共同選項：
  --config <file.json>   連線設定（預設 ./minio.json、./.dsh/minio.json、$MINIO_CONFIG）
  --bucket <桶>          預設桶（可省略，改用設定裡的 bucket）
  --json                 輸出 JSON（適合程式解析）
`

/** 把 `init` 收進來的設定驗一遍，缺欄位就擋下來（避免寫進一份不能用的檔）。 */
function validateIncomingConfig(raw) {
  const endpoint = pick(raw, ['endpoint', 'S3_URL', 'url', 'host'])
  const accessKey = pick(raw, ['accessKey', 'accessKeyId', 'S3_UID', 'UID'])
  const secretKey = pick(raw, ['secretKey', 'secretAccessKey', 'S3_PWD', 'PWD'])
  const missing = []
  if (endpoint === '') missing.push('endpoint')
  if (accessKey === '') missing.push('accessKey')
  if (secretKey === '') missing.push('secretKey')
  if (missing.length > 0) {
    fail('ConfigMissing', `匯出的設定缺少 ${missing.join('、')}。面板的「❗️ 複製設定」應該會給 endpoint/accessKey/secretKey/region/bucket。`)
  }
  return { endpoint, accessKey, secretKey, bucket: pick(raw, ['bucket', 'S3_BUCK', 'BUCKET']), region: pick(raw, ['region', 'S3_REGION']) }
}

async function runInit(args) {
  let text
  if (typeof args.flags.content === 'string') text = args.flags.content
  else if (typeof args.flags.from === 'string') {
    try { text = readFileSync(args.flags.from, 'utf8') } catch (error) { fail('ConfigUnreadable', `讀不到 ${args.flags.from}：${error.message}`) }
  } else if (process.stdin.isTTY) {
    fail('MissingInput', '請把匯出的 JSON 貼進來（stdin），或用 --from <file> / --content \'<json>\'。')
  } else {
    try { text = readFileSync(0, 'utf8') } catch (error) { fail('ConfigUnreadable', `讀不到 stdin：${error.message}`) }
  }

  let raw
  try { raw = JSON.parse(String(text).trim()) } catch (error) { fail('InvalidJson', `不是合法 JSON：${error.message}`) }
  const fields = validateIncomingConfig(raw)

  const out = typeof args.flags.out === 'string' ? args.flags.out : 'minio.json'
  writeFileSync(out, JSON.stringify(raw, null, 2) + '\n', { mode: 0o600 })
  const payload = { ok: true, path: out, source: 'init', ...fields, secretKey: `${String(fields.secretKey).slice(0, 2)}***` }
  if (args.flags.json) process.stdout.write(JSON.stringify(payload, null, 2) + '\n')
  else {
    process.stdout.write(`已寫入 ${out}\n`
      + `  endpoint  ${fields.endpoint}\n`
      + `  accessKey ${fields.accessKey}\n`
      + `  secretKey ${String(fields.secretKey).slice(0, 2)}***（已遮蔽）\n`
      + `  region    ${fields.region || '(未指定，使用時自動探測)'}\n`
      + `  bucket    ${fields.bucket || '(未指定，用 --bucket 指定)'}\n`
      + `這份檔案含金鑰：不要 commit、不要貼給別人；要改金鑰/端點/預設桶就再跑一次 init，或直接編輯它。\n`)
  }
}

async function main() {
  const args = parseArgv(process.argv.slice(2))
  const command = args._[0]
  if (!command || args.flags.help) {
    process.stdout.write(USAGE)
    // 沒有命令才是用法錯誤；單純 `--help` 是正常結束。
    if (!command && !args.flags.help) process.exitCode = 1
    return
  }
  // init 必須在 loadConfig 之前：那時還沒有一份可用的設定。
  if (command === 'init') {
    await runInit(args)
    return
  }

  const config = loadConfig(args)
  const client = makeClient(config)
  await client.probeRegion()

  const bucket = args.flags.bucket === undefined ? config.bucket : String(args.flags.bucket)
  const needBucket = () => {
    if (!bucket) fail('BucketMissing', '缺少桶名：設定裡沒有 bucket，請加 --bucket <桶>')
    return bucket
  }
  const keys = args.key.length > 0 ? args.key : (typeof args.flags.key === 'string' ? [args.flags.key] : [])
  const print = (payload, human) => {
    if (args.flags.json) process.stdout.write(JSON.stringify(payload, null, 2) + '\n')
    else process.stdout.write(human + '\n')
  }

  switch (command) {
    case 'config': {
      const mask = (value) => (typeof value === 'string' && value.length > 2
        ? `${value.slice(0, 2)}***`
        : '***')
      const info = {
        source: config.source,
        endpoint: config.endpoint,
        accessKey: config.accessKey,
        secretKey: mask(config.secretKey),
        region: client.state.region,
        regionPinned: Boolean(config.region),
        bucket: config.bucket || '(未指定)',
      }
      print(info, `設定來源 ${config.source}\n`
        + `  endpoint  ${info.endpoint}\n`
        + `  accessKey ${info.accessKey}\n`
        + `  secretKey ${info.secretKey}（已遮蔽）\n`
        + `  region    ${info.region}${info.regionPinned ? '' : '（自動探測）'}\n`
        + `  bucket    ${info.bucket}`)
      break
    }
    case 'buckets': {
      const buckets = await listBuckets(client)
      print({ endpoint: config.endpoint, region: client.state.region, buckets },
        buckets.map((entry) => `${entry.name}\t${entry.createdAt}`).join('\n') || '(沒有桶)')
      break
    }
    case 'ls': {
      const listing = await listObjects(client, needBucket(), args._[1] || '', args.flags.recursive === true,
        Number(args.flags.max || 200))
      const lines = []
      for (const folder of listing.folders) lines.push(`dir\t${folder}`)
      for (const entry of listing.objects) lines.push(`${entry.size}\t${entry.lastModified}\t${entry.key}`)
      print({ bucket, region: client.state.region, ...listing }, lines.join('\n') || '(空)')
      break
    }
    case 'head': {
      const response = await client.send({ method: 'HEAD', url: client.objectUrl(needBucket(), keys[0]) })
      const info = {
        key: keys[0],
        size: Number(response.headers.get('content-length') || 0),
        contentType: response.headers.get('content-type') || '',
        etag: (response.headers.get('etag') || '').replace(/^"|"$/g, ''),
        lastModified: response.headers.get('last-modified') || '',
      }
      print(info, `${info.size}\t${info.lastModified}\t${info.contentType}`)
      break
    }
    case 'get': {
      const result = await getObject(client, needBucket(), keys[0], args.flags.out)
      if (args.flags.out) {
        print({ key: keys[0], out: args.flags.out, bytes: result.bytes }, `wrote ${args.flags.out} (${result.bytes} bytes)`)
      } else {
        process.stdout.write(result.body)
      }
      break
    }
    case 'cat': {
      const result = await getObject(client, needBucket(), keys[0])
      process.stdout.write(args.flags.json
        ? JSON.stringify({ key: keys[0], bytes: result.bytes, content: result.body.toString('utf8') }, null, 2) + '\n'
        : result.body.toString('utf8'))
      break
    }
    case 'put': {
      let body
      if (typeof args.flags.from === 'string') body = readFileSync(args.flags.from)
      else if (typeof args.flags.content === 'string') body = Buffer.from(args.flags.content, 'utf8')
      else fail('MissingBody', '需要 --from <path> 或 --content <text>')
      const result = await putObject(client, needBucket(), keys[0], body, args.flags.contentType)
      print(result, `put ${result.key} (${result.bytes} bytes)`)
      break
    }
    case 'rm': {
      if (keys.length === 0) fail('MissingKey', '需要 --key <key>')
      const result = await deleteObjects(client, needBucket(), keys)
      if (result.errors.length > 0) {
        print(result, `刪除 ${result.deleted.length}/${keys.length}，失敗：${result.errors.map((e) => `${e.key} ${e.code}`).join('、')}`)
        process.exitCode = 1
      } else {
        print(result, `deleted ${result.deleted.length}${result.retried.length ? ` (${result.retried.length} 改用單物件刪除)` : ''}`)
      }
      break
    }
    case 'mv': {
      if (typeof args.flags.to !== 'string') fail('MissingTarget', '需要 --to <目標 key>')
      await copyObject(client, needBucket(), keys[0], args.flags.to)
      const result = await deleteObjects(client, needBucket(), [keys[0]])
      if (result.errors.length > 0) {
        print({ copied: true, deleted: false, ...result }, `已複製到 ${args.flags.to}，但原檔刪不掉：${result.errors.map((e) => e.code).join('、')}`)
        process.exitCode = 1
      } else {
        print({ from: keys[0], to: args.flags.to }, `${keys[0]} → ${args.flags.to}`)
      }
      break
    }
    case 'mkdir': {
      const result = await putObject(client, needBucket(), keys[0], Buffer.alloc(0), 'application/x-directory')
      print(result, `mkdir ${result.key}`)
      break
    }
    case 'mb': {
      await client.send({ method: 'PUT', url: client.objectUrl(needBucket(), '') })
      print({ bucket, created: true }, `bucket ${bucket} created`)
      break
    }
    case 'rb': {
      await client.send({ method: 'DELETE', url: client.objectUrl(needBucket(), '') })
      print({ bucket, deleted: true }, `bucket ${bucket} deleted`)
      break
    }
    case 'presign': {
      const url = presign({
        url: client.objectUrl(needBucket(), keys[0]),
        accessKey: config.accessKey,
        secretKey: config.secretKey,
        region: client.state.region,
        expires: Number(args.flags.expires || 3600),
      })
      print({ key: keys[0], expires: Number(args.flags.expires || 3600), url }, url)
      break
    }
    default:
      fail('UnknownCommand', `不認得的命令：${command}（用 --help 看用法）`)
  }
}

main().catch((error) => {
  process.stderr.write(`error: ${(error && error.message) || String(error)}\n`)
  process.exitCode = 1
})
